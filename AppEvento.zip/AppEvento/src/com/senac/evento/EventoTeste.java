package com.senac.evento;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import java.awt.BorderLayout;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JButton;

public class EventoTeste {
	private static JTextField txtnome;
	private static JTextField txtdata;
	public static DefaultTableModel tableModel;
    public static void main(String[] args) {
        
    	JFrame frame = new JFrame(); 
        frame.setVisible(true);
        frame.setSize(450, 500); // width e height
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        
        JLabel lblnome = new JLabel("Nome");
        lblnome.setFont(new Font("Comic Sans MS", Font.PLAIN, 14));
        lblnome.setBounds(51, 55, 64, 27);
        frame.getContentPane().add(lblnome);
        
        JLabel lblData = new JLabel("Data");
        lblData.setFont(new Font("Comic Sans MS", Font.PLAIN, 14));
        lblData.setBounds(51, 105, 64, 27);
        frame.getContentPane().add(lblData);
        
        txtnome = new JTextField();
        txtnome.setBounds(125, 54, 237, 32);
        frame.getContentPane().add(txtnome);
        txtnome.setColumns(10);
        
        txtdata = new JTextField();
        txtdata.setColumns(10);
        txtdata.setBounds(125, 110, 237, 32);
        frame.getContentPane().add(txtdata);
        
        JCheckBox chcativo = new JCheckBox("Ativo");
        chcativo.setFont(new Font("Tahoma", Font.PLAIN, 14));
        chcativo.setBounds(265, 177, 97, 23);
        frame.getContentPane().add(chcativo);
        
        JButton btnenviar = new JButton("Enviar");
        btnenviar.setFont(new Font("Tahoma", Font.PLAIN, 14));
        btnenviar.setBounds(51, 238, 311, 27);
        frame.getContentPane().add(btnenviar);
        
        JLabel lblInfo = new JLabel("");
        lblInfo.setBounds(51, 300, 500, 27);
        frame.getContentPane().add(lblInfo);
        
        // Crie um modelo de tabela com as colunas desejadas
        tableModel = new DefaultTableModel();
        tableModel.addColumn("Nome");
        tableModel.addColumn("Data");
        tableModel.addColumn("Ativo");

        // Crie o JTable com o modelo de tabela criado
        JTable table = new JTable(tableModel);

        // Adicione o JTable a um JScrollPane para exibir a barra de rolagem, caso necessário
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(51, 300, 500, 200);
        frame.getContentPane().add(scrollPane);


        
        btnenviar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                
                Cadastrar objcadastrar = new Cadastrar();
                objcadastrar.cadastrarEvento(txtnome.getText(), txtdata.getText(), chcativo.isSelected());

                Exibir objexibir = new Exibir();
                objexibir.exibirEventos(txtnome.getText(), txtdata.getText(), chcativo.isSelected());

            }
        });
    }
}
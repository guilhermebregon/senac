package com.senac.evento;

import java.sql.Connection; // configuracao de conexao pega o driver
import java.sql.DriverManager; // drivers para trazer o DB
import java.sql.PreparedStatement; // instrucao preparada sql
import java.sql.ResultSet; // pega instrucao
import java.sql.SQLException; // previne erros sql

public class Exibir {
    public void exibirEventos(String string, String string2, boolean b) {
        try {
        	
        	Connection conexao = DriverManager.getConnection(
        							"jdbc:mysql://localhost:3306/novo", 
        							"root", 
        							"Sen@cEdu22" );
        	
            String sql = "SELECT * FROM Evento";
            PreparedStatement instrucao = conexao.prepareStatement(sql);
            ResultSet resultado = instrucao.executeQuery();

            EventoTeste.tableModel.setRowCount(0);
            


            while (resultado.next()) {
                String nome = resultado.getString("nome");
                String data = resultado.getString("data");
                boolean ativo = resultado.getBoolean("ativo");

                // Adicione uma nova linha com os dados obtidos
                Object[] rowData = {nome, data, ativo};
                EventoTeste.tableModel.addRow(rowData);
            }
        } catch (SQLException e) {
            System.out.println("Erro ao exibir eventos: " + e);
        }
    }
}

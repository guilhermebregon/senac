package com.senac.evento;

public class Evento {
	public String nome;
	public String data;
}
